package perform;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MenuSelection {
    public static void main(String[] args) {
        ArrayList<HashMap<String, Integer>> dishesList = new ArrayList<>();

        // Input for Monday Lunch
        HashMap<String, Integer> mondayLunchVotes = new HashMap<>();
        getVotesForDishes(mondayLunchVotes, "Monday Lunch", "dry", "gravy");
        dishesList.add(mondayLunchVotes);

        // Input for Monday Dinner
        HashMap<String, Integer> mondayDinnerVotes = new HashMap<>();
        getVotesForDishes(mondayDinnerVotes, "Monday Dinner", "dry", "gravy");
        dishesList.add(mondayDinnerVotes);

        // Input for Tuesday Lunch
        HashMap<String, Integer> tuesdayLunchVotes = new HashMap<>();
        getVotesForDishes(tuesdayLunchVotes, "Tuesday Lunch", "dry", "gravy");
        dishesList.add(tuesdayLunchVotes);

        // Input for Tuesday Dinner
        HashMap<String, Integer> tuesdayDinnerVotes = new HashMap<>();
        getVotesForDishes(tuesdayDinnerVotes, "Tuesday Dinner", "dry", "gravy");
        dishesList.add(tuesdayDinnerVotes);

        // Input for Wednesday Lunch
        HashMap<String, Integer> wednesdayLunchVotes = new HashMap<>();
        getVotesForDishes(wednesdayLunchVotes, "Wednesday Lunch", "dry", "gravy");
        dishesList.add(wednesdayLunchVotes);

        // Input for Wednesday Dinner
        HashMap<String, Integer> wednesdayDinnerVotes = new HashMap<>();
        getVotesForDishes(wednesdayDinnerVotes, "Wednesday Dinner", "dry", "gravy");
        dishesList.add(wednesdayDinnerVotes);

        // Input for Thursday Lunch
        HashMap<String, Integer> thursdayLunchVotes = new HashMap<>();
        getVotesForDishes(thursdayLunchVotes, "Thursday Lunch", "dry", "gravy");
        dishesList.add(thursdayLunchVotes);

        // Input for Thursday Dinner
        HashMap<String, Integer> thursdayDinnerVotes = new HashMap<>();
        getVotesForDishes(thursdayDinnerVotes, "Thursday Dinner", "dry", "gravy");
        dishesList.add(thursdayDinnerVotes);

        // Find the dish with the maximum votes for each day and meal time and print it
        for (int i = 0; i < dishesList.size(); i += 2) { // increment by 2 to get both lunch and dinner HashMaps for each day
            HashMap<String, Integer> lunchVotes = dishesList.get(i);
            HashMap<String, Integer> dinnerVotes = dishesList.get(i + 1);
            String maxVotedLunchDish = findMaxVotedDish(lunchVotes);
            String maxVotedDinnerDish = findMaxVotedDish(dinnerVotes);
            System.out.println("Final dish for " + getDayName(i / 2) + " Lunch: " + maxVotedLunchDish);
            System.out.println("Final dish for " + getDayName(i / 2) + " Dinner: " + maxVotedDinnerDish);
        }
    }

    public static void getVotesForDishes(HashMap<String, Integer> votesMap, String mealTime, String... dishTypes) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter votes for dishes on " + mealTime + ":");
        for (String dishType : dishTypes) {
            for (int i = 1; i <= 7; i++) {
                System.out.print("Enter votes for " + mealTime + " " + dishType + " sabzi" + i + ": ");
                int votes = scanner.nextInt();
                votesMap.put(dishType + " Sabzi" + i, votes);
            }
        }
    }

    public static String findMaxVotedDish(HashMap<String, Integer> votesMap) {
        String maxVotedDish = "";
        int maxVotes = Integer.MIN_VALUE;
        for (String dish : votesMap.keySet()) {
            int votes = votesMap.get(dish);
            if (votes > maxVotes) {
                maxVotes = votes;
                maxVotedDish = dish;
            }
        }
        return maxVotedDish;
    }

    public static String getDayName(int dayIndex) {
        switch (dayIndex) {
            case 0:
                return "Monday";
            case 1:
                return "Tuesday";
            case 2:
                return "Wednesday";
            case 3:
                return "Thursday";
            case 4:
                return "Friday";
            case 5:
                return "Saturday";
            case 6:
                return "Sunday";
            default:
                return "Unknown";
        }
    }
}
