package perform;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainRunAllClasses {
	public static void main(String args[])
	{
		String params[] = new String[] {};
		
		Scanner in=new Scanner(System.in);
		boolean flag=true;
		int ch;
		
		while(flag==true)
		{
			try {
				System.out.println("Enter choice:\n1.Grievance Redressal\n2.MenuSelection\n3.Mess Registration\n4.Night Out Application\n 0.Exit ");
				ch=in.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println(e);
				ch=1000;
			}
			switch(ch)
			{
			case 1:
				GrievanceRedressal.main(params);
				break;
				
			case 2:
				MenuSelection.main(params);
				break;
				
			case 3:
				messRegister.main(params);
				break;
				
			case 4:
				NightOutApplication.main(params);
				break;
				
			case 0:
				flag=false;
				break;
				
			default:
				System.out.println("Illegal choice detected, try again!");
			}
		}
	}
}
