package perform;
import java.util.*;
public class messRegister {
	protected static Map<String, Integer>messCapacity;
	protected static Map<String, Integer>messRegistration;
	protected static ArrayList<Hostelite> hosteliteRecord;
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		
		messCapacity = new HashMap<>();
        messRegistration = new HashMap<>();
        hosteliteRecord=new ArrayList<>();

        // Initialize mess capacities
        messCapacity.put("h1", 250);
        messCapacity.put("h2", 350);
        messCapacity.put("h3", 250);

        // Initialize mess registrations
        messRegistration.put("h1", 0);
        messRegistration.put("h2", 0);
        messRegistration.put("h3", 0);
        
		boolean flag=true;
		int ch;
		
		while(flag==true)
		{
			try{System.out.println("Enter Choice\n1.Add student Details and select mess\n2.See alloted mess\n0.Exit");
			ch=in.nextInt();
			in.nextLine();}
			catch(InputMismatchException e)
			{
				System.out.println(e);
				ch=1000;
			}
			
			switch(ch)
			{
			case 1:
				System.out.println("Enter name, hostel ID, mess of choice(i.e. h1, h2, h3)");
				String n=in.nextLine();
				String hid1=in.nextLine();
				String cm=in.nextLine();
				
				hosteliteRecord.add(new Hostelite(n, hid1, cm, "0"));
				break;
				
			case 2:
				for(int i=0;i<hosteliteRecord.size();i++)
				{
					registerStudent(hosteliteRecord.get(i).chosenMess, i);
				}
		
				System.out.println("Enter your hostel ID:");
				String hid=in.next();
				for(int j=0;j<hosteliteRecord.size();j++)
				{
					if(hid.equalsIgnoreCase(hosteliteRecord.get(j).hostelID))
							{
						System.out.println("Mess Alloted: " + hosteliteRecord.get(j).allottedMess);
							}
				}
				break;
				
			case 0:
				flag=false;
				break;
				
			default:
				System.out.println("Illegal choice detected, try again!");
				break;
			}
		}
	}
	
	public static void registerStudent(String mess, int i)
	{
		
		 if (messRegistration.get(mess) < messCapacity.get(mess)) {
	            messRegistration.put(mess, messRegistration.get(mess) + 1);
	            hosteliteRecord.get(i).allottedMess = mess;

	        } else {
	            for (Map.Entry<String, Integer> entry : messRegistration.entrySet()) {
	                if (entry.getValue() < messCapacity.get(entry.getKey())) {
	                    messRegistration.put(entry.getKey(), messRegistration.get(entry.getKey()) + 1);
	                    hosteliteRecord.get(i).allottedMess = entry.getKey();
	                    return;
	                }
	            }
	            System.out.println("All messes are full. The student could not be registered.");
	        }
                
		
	}
	
}
class Hostelite{
	String name;
	String hostelID;
	String chosenMess;
	String allottedMess;
	
	Hostelite(String n, String h, String cm, String am)
	{
		name=n;
		hostelID=h;
		chosenMess=cm;
		allottedMess=am;
	}
}