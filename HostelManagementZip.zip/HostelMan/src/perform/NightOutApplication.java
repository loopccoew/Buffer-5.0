package perform;

import java.util.*;
import java.time.LocalDate;
class NightOut {
    protected int id;
    protected String reason;
    protected int noOfDays;
    protected LocalDate dateOfGoingOut;
    protected LocalDate dateOfReporting;
    protected String place;
    protected Boolean statusOfApproval;

    public NightOut(int id, String reason, int noOfDays, LocalDate dateGoingOut, LocalDate dateReporting, String place) {
        this.id = id;
        this.reason = reason;
        this.noOfDays = noOfDays;
        this.dateOfGoingOut = dateGoingOut;
        this.dateOfReporting = dateReporting;
        this.place = place;
        this.statusOfApproval = null; // Initially set as null
    }

    public int getId() {
        return id;
    }

    public void displayDetails() {
        System.out.println("ID: " + id);
        System.out.println("Reason: " + reason);
        System.out.println("Number of Days: " + noOfDays);
        System.out.println("Date of Going Out: " + dateOfGoingOut);
        System.out.println("Date of Reporting: " + dateOfReporting);
        System.out.println("Place: " + place);
        System.out.println("Approval Status: " + (statusOfApproval == null ? "Pending" : (statusOfApproval ? "Approved" : "Rejected")));
    }

    public void approveNightOut(boolean approval) {
        this.statusOfApproval = approval;
    }
}

public class NightOutApplication{
    protected static List<NightOut> nightOutList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nNight Out Management System");
            System.out.println("1. Add Night Out");
            System.out.println("2. Display All Night Outs");
            System.out.println("3. Approve Night Out");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addNightOut(scanner);
                    break;
                case 2:
                    displayAllNightOuts();
                    break;
                case 3:
                    approveNightOut(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 4);
        scanner.close();
    }

    protected static void addNightOut(Scanner scanner) {
        System.out.println("\nEnter Night Out Details:");
        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        System.out.print("Reason: ");
        String reason = scanner.nextLine();
        System.out.print("Number of Days: ");
        int noOfDays = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        System.out.print("Date of Going Out (yyyy-MM-dd): ");
        String strDateGoingOut = scanner.nextLine();
        LocalDate dateGoingOut = LocalDate.parse(strDateGoingOut);
        System.out.print("Date of Reporting (yyyy-MM-dd): ");
        String strDateReporting = scanner.nextLine();
        LocalDate dateReporting = LocalDate.parse(strDateReporting);
        System.out.print("Place: ");
        String place = scanner.nextLine();

        NightOut nightOut = new NightOut(id, reason, noOfDays, dateGoingOut, dateReporting, place);
        nightOutList.add(nightOut);
        System.out.println("Night Out added successfully!");
    }


    protected static void displayAllNightOuts() {
        if (nightOutList.isEmpty()) {
            System.out.println("No Night Outs registered yet.");
        } else {
            System.out.println("\nAll Night Outs:");
            for (NightOut nightOut : nightOutList) {
                nightOut.displayDetails();
                System.out.println("-------------------------");
            }
        }
    }

    protected static void approveNightOut(Scanner scanner) {
        if (nightOutList.isEmpty()) {
            System.out.println("No Night Outs registered yet.");
        } else {
            System.out.print("Enter the ID of Night Out to approve: ");
            int id = scanner.nextInt();
            NightOut nightOut = findNightOutById(id);
            if (nightOut == null) {
                System.out.println("Night Out with ID " + id + " not found.");
            } else {
                System.out.print("Approve? (true/false): ");
                boolean approval = scanner.nextBoolean();
                nightOut.approveNightOut(approval);
                System.out.println("Night Out with ID " + id + " approved/rejected successfully.");
            }
        }
    }

    protected static NightOut findNightOutById(int id) {
        for (NightOut nightOut : nightOutList) {
            if (nightOut != null && nightOut.getId() == id) {
                return nightOut;
            }
        }
        return null;
    }
}
