package perform;

import java.util.PriorityQueue;
import java.util.Scanner;

// Class to represent a grievance
class Grievance implements Comparable<Grievance> {
    protected String description;
    protected int severity;

    public Grievance(String description, int severity) {
        this.description = description;
        this.severity = severity;
    }

    public String getDescription() {
        return description;
    }

    public int getSeverity() {
        return severity;
    }

    @Override
    public int compareTo(Grievance other) {
        // Higher severity grievances will have higher priority
        return Integer.compare(other.severity, this.severity);
    }
}

public class GrievanceRedressal {
    public static void main(String[] args) {
        // Priority queue to store grievances
        PriorityQueue<Grievance> grievances = new PriorityQueue<>();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter grievance description (or 'exit' to stop): ");
            String description = scanner.nextLine();

            if (description.equalsIgnoreCase("exit")) {
                break;
            }

            System.out.print("Rate the severity of the grievance (1 to 5, 5 being the highest): ");
            int severity = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Create a new grievance object
            Grievance grievance = new Grievance(description, severity);

            // Add the grievance to the priority queue
            grievances.offer(grievance);
        }

        // Process grievances from highest to lowest severity
        System.out.println("Grievances sorted by severity:");
        while (!grievances.isEmpty()) {
            Grievance grievance = grievances.poll();
            System.out.println("Description: " + grievance.getDescription() + ", Severity: " + grievance.getSeverity());

            // Send email to respective hostelites
            sendEmail(grievance.getDescription());
        }
    }

    // Dummy method to simulate sending emails
    protected static void sendEmail(String description) {
        // Your email sending logic here
        System.out.println("Email sent for grievance: " + description);
    }
}

