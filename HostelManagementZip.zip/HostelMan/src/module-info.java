/**
 * 
 */
/**
 * 
 */
module HostelMan {
}